pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // مكتبة NewPipeExtractor منشورة على JitPack
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "AlMarw"
include(":app")
