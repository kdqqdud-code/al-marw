package com.almarw.app.data

import androidx.compose.runtime.Immutable
import androidx.core.text.HtmlCompat
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.stream.Description
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType

/** نماذج مبسّطة للواجهة: تفصل شاشات Compose عن كائنات المكتبة */
@Immutable
sealed interface UiItem {
    val url: String
    val title: String
    val thumbnail: String?

    data class Video(
        override val url: String,
        override val title: String,
        override val thumbnail: String?,
        val uploader: String,
        val durationSec: Long,
        val views: Long,
        val uploadedAgo: String?,
        val isLive: Boolean,
    ) : UiItem

    data class Channel(
        override val url: String,
        override val title: String,
        override val thumbnail: String?,
        val subscribers: Long,
    ) : UiItem

    data class Playlist(
        override val url: String,
        override val title: String,
        override val thumbnail: String?,
        val uploader: String,
        val count: Long,
    ) : UiItem
}

@Immutable
data class VideoDetails(
    val url: String,
    val title: String,
    val uploader: String,
    val uploaderAvatar: String?,
    val thumbnail: String?,
    val views: Long,
    val uploadedAgo: String?,
    val description: String,
    val isLive: Boolean,
    val related: List<UiItem>,
)

/** يختار أوضح صورة من قائمة الأحجام التي يعيدها يوتيوب */
fun List<Image>.bestUrl(): String? = maxByOrNull { it.height }?.url

fun StreamType.isLive(): Boolean =
    this == StreamType.LIVE_STREAM || this == StreamType.AUDIO_LIVE_STREAM

fun InfoItem.toUiItem(): UiItem? = when (this) {
    is StreamInfoItem -> UiItem.Video(
        url = url,
        title = name,
        thumbnail = thumbnails.bestUrl(),
        uploader = uploaderName.orEmpty(),
        durationSec = duration,
        views = viewCount,
        uploadedAgo = textualUploadDate,
        isLive = streamType.isLive(),
    )
    is ChannelInfoItem -> UiItem.Channel(
        url = url,
        title = name,
        thumbnail = thumbnails.bestUrl(),
        subscribers = subscriberCount,
    )
    is PlaylistInfoItem -> UiItem.Playlist(
        url = url,
        title = name,
        thumbnail = thumbnails.bestUrl(),
        uploader = uploaderName.orEmpty(),
        count = streamCount,
    )
    else -> null
}

fun StreamInfo.toDetails(): VideoDetails = VideoDetails(
    url = url,
    title = name,
    uploader = uploaderName.orEmpty(),
    uploaderAvatar = uploaderAvatars.bestUrl(),
    thumbnail = thumbnails.bestUrl(),
    views = viewCount,
    uploadedAgo = textualUploadDate,
    description = description.toPlainText(),
    isLive = streamType.isLive(),
    related = relatedItems.orEmpty().mapNotNull { it?.toUiItem() },
)

/** وصف يوتيوب يصل بصيغة HTML؛ نحوّله لنص عادي للعرض */
private fun Description?.toPlainText(): String = when {
    this == null -> ""
    type == Description.HTML ->
        HtmlCompat.fromHtml(content, HtmlCompat.FROM_HTML_MODE_COMPACT).toString().trim()
    else -> content.orEmpty()
}
