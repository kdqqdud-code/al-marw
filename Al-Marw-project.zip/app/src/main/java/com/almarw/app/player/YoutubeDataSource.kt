package com.almarw.app.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import com.almarw.app.data.DownloaderImpl
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper
import java.util.concurrent.atomic.AtomicLong

/**
 * طبقة الشبكة الخاصة بالمشغّل.
 * يوتيوب يرفض روابط البث (خطأ 403) إذا لم تطابق الهيدرات "العميل" الذي استُخرج منه الرابط
 * (Android / iOS / visionOS / Web). هذه نسخة مبسّطة من YoutubeHttpDataSource في NewPipe.
 */
@OptIn(UnstableApi::class)
object YoutubeDataSource {

    /** تطبيقات يوتيوب الرسمية تطلب ملفات البث بـ POST. إن ظهر خطأ 400/403 جرّب false (طلبات GET) */
    private const val USE_POST = true
    private val POST_BODY = byteArrayOf(0x78, 0x00)
    private const val YOUTUBE_ORIGIN = "https://www.youtube.com"
    private val requestNumber = AtomicLong(0)

    fun factory(context: Context): DataSource.Factory {
        val http = OkHttpDataSource.Factory(DownloaderImpl.instance.client)
            .setDefaultRequestProperties(mapOf("User-Agent" to DownloaderImpl.USER_AGENT))
        val youtube = ResolvingDataSource.Factory(http) { spec -> adapt(spec) }
        // DefaultDataSource يضيف دعم الملفات المحلية (للمقاطع المحمّلة في المرحلة القادمة)
        return DefaultDataSource.Factory(context, youtube)
    }

    private fun adapt(spec: DataSpec): DataSpec {
        if (spec.uri.path?.startsWith("/videoplayback") != true) return spec
        val url = spec.uri.toString()

        val headers = HashMap(spec.httpRequestHeaders)
        when {
            YoutubeParsingHelper.isAndroidStreamingUrl(url) ->
                headers["User-Agent"] = YoutubeParsingHelper.getAndroidUserAgent(null)
            YoutubeParsingHelper.isIosStreamingUrl(url) ->
                headers["User-Agent"] = YoutubeParsingHelper.getIosUserAgent(null)
            YoutubeParsingHelper.isVisionOsStreamingUrl(url) ->
                headers["User-Agent"] = YoutubeParsingHelper.getVisionOsUserAgent(null)
            YoutubeParsingHelper.isWebStreamingUrl(url) ||
                YoutubeParsingHelper.isWebEmbeddedPlayerStreamingUrl(url) -> {
                headers["Origin"] = YOUTUBE_ORIGIN
                headers["Referer"] = "$YOUTUBE_ORIGIN/"
                headers["Sec-Fetch-Dest"] = "empty"
                headers["Sec-Fetch-Mode"] = "cors"
                headers["Sec-Fetch-Site"] = "cross-site"
            }
        }

        // رقم تسلسلي للطلبات (rn) كما تفعل تطبيقات يوتيوب الرسمية
        val uri = if (spec.uri.getQueryParameter("rn") == null) {
            spec.uri.buildUpon()
                .appendQueryParameter("rn", requestNumber.incrementAndGet().toString())
                .build()
        } else {
            spec.uri
        }

        val builder = spec.buildUpon()
            .setUri(uri)
            .setHttpRequestHeaders(headers)
        if (USE_POST) {
            builder.setHttpMethod(DataSpec.HTTP_METHOD_POST).setHttpBody(POST_BODY)
        }
        return builder.build()
    }
}
