package com.almarw.app.data

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.util.concurrent.TimeUnit

/**
 * الجسر بين NewPipeExtractor والإنترنت.
 * المكتبة لا تتصل بالشبكة بنفسها: كل طلب تحتاجه يمر من هنا عبر OkHttp.
 */
class DownloaderImpl private constructor(val client: OkHttpClient) : Downloader() {

    override fun execute(request: Request): Response {
        val builder = okhttp3.Request.Builder()
            .url(request.url())
            .method(request.httpMethod(), request.dataToSend()?.toRequestBody())
            .header("User-Agent", USER_AGENT)

        // الهيدرات التي تطلبها المكتبة (هوية العميل، الكوكيز...) لها الأولوية
        request.headers().forEach { (name, values) ->
            builder.removeHeader(name)
            values.forEach { value -> builder.addHeader(name, value) }
        }

        return client.newCall(builder.build()).execute().use { response ->
            if (response.code == 429) {
                // طلبات كثيرة من نفس الشبكة: يوتيوب يطلب التحقق (reCAPTCHA)
                throw ReCaptchaException("reCaptcha challenge requested", request.url())
            }
            Response(
                response.code,
                response.message,
                response.headers.toMultimap(),
                response.body?.string(),
                response.request.url.toString(),
            )
        }
    }

    companion object {
        /** نفس أسلوب NewPipe: متصفح Firefox ESR على سطح المكتب */
        const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

        val instance: DownloaderImpl by lazy {
            DownloaderImpl(
                OkHttpClient.Builder()
                    .connectTimeout(20, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build()
            )
        }
    }
}
