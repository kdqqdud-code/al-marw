package com.almarw.app.ui.common

import android.icu.text.CompactDecimalFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.almarw.app.R
import org.schabi.newpipe.extractor.exceptions.AgeRestrictedContentException
import org.schabi.newpipe.extractor.exceptions.ContentNotAvailableException
import org.schabi.newpipe.extractor.exceptions.GeographicRestrictionException
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.exceptions.SignInConfirmNotBotException
import java.io.IOException
import java.util.Locale

// كلمات عربية مع أرقام لاتينية مثل يوتيوب العربي: "1.2 مليون"
private val arabicLatinDigits: Locale = Locale.forLanguageTag("ar-u-nu-latn")

fun formatCount(n: Long): String? {
    if (n < 0) return null
    return CompactDecimalFormat
        .getInstance(arabicLatinDigits, CompactDecimalFormat.CompactStyle.SHORT)
        .format(n)
}

/** 754 ثانية ← "12:34" */
fun formatDuration(seconds: Long): String? {
    if (seconds <= 0) return null
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) {
        String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    } else {
        String.format(Locale.US, "%d:%02d", m, s)
    }
}

/** رسالة مفهومة للمستخدم بدل رسالة المكتبة التقنية */
@Composable
fun errorMessage(error: Throwable): String = when (error) {
    is ReCaptchaException, is SignInConfirmNotBotException -> stringResource(R.string.error_captcha)
    is AgeRestrictedContentException -> stringResource(R.string.error_age)
    is GeographicRestrictionException -> stringResource(R.string.error_geo)
    is ContentNotAvailableException -> stringResource(R.string.error_unavailable)
    is IOException -> stringResource(R.string.error_network)
    else -> stringResource(R.string.error_generic, error.message ?: error.javaClass.simpleName)
}

@Composable
fun ErrorBox(error: Throwable, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            errorMessage(error),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
        )
        OutlinedButton(onClick = onRetry) { Text(stringResource(R.string.retry)) }
    }
}

@Composable
fun EmptyHint(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
