package com.almarw.app.data

import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.StreamingService
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo

enum class SearchFilter(val contentFilters: List<String>) {
    ALL(emptyList()),
    VIDEOS(listOf(YoutubeSearchQueryHandlerFactory.VIDEOS)),
    CHANNELS(listOf(YoutubeSearchQueryHandlerFactory.CHANNELS)),
}

/** صفحة نتائج + ما يلزم لجلب الصفحة التالية */
data class SearchPage(
    val items: List<UiItem>,
    val nextPage: Page?,
    val query: SearchQueryHandler,
    val suggestion: String?,
)

/**
 * كل التعامل مع NewPipeExtractor في مكان واحد.
 * المكتبة تتصل بالشبكة بشكل متزامن (blocking)، لذا كل الدوال suspend وتعمل على Dispatchers.IO.
 */
object NewPipeRepository {

    private val youtube: StreamingService get() = ServiceList.YouTube

    // الواجهة وخدمة التشغيل تطلبان نفس المقطع، فنجلبه مرة واحدة ونحفظه مؤقتاً.
    // روابط البث تنتهي صلاحيتها بعد ساعات، لذلك مدة الحفظ 30 دقيقة فقط.
    private const val CACHE_TTL_MS = 30 * 60 * 1000L
    private val cache = LruCache<String, Pair<Long, StreamInfo>>(30)

    /** البحث عن فيديوهات/قنوات */
    suspend fun search(query: String, filter: SearchFilter): SearchPage = withContext(Dispatchers.IO) {
        val handler = youtube.searchQHFactory.fromQuery(query, filter.contentFilters, "")
        val info = SearchInfo.getInfo(youtube, handler)
        SearchPage(
            items = info.relatedItems.mapNotNull { it.toUiItem() },
            nextPage = info.nextPage,
            query = handler,
            suggestion = info.searchSuggestion?.takeIf { it.isNotBlank() },
        )
    }

    /** الصفحة التالية من نتائج البحث (التمرير اللانهائي) */
    suspend fun searchMore(current: SearchPage): SearchPage = withContext(Dispatchers.IO) {
        val page = current.nextPage ?: return@withContext current
        val more = SearchInfo.getMoreItems(youtube, current.query, page)
        current.copy(
            items = current.items + more.items.mapNotNull { it.toUiItem() },
            nextPage = more.nextPage,
        )
    }

    /** اقتراحات البحث أثناء الكتابة */
    suspend fun suggestions(query: String): List<String> = withContext(Dispatchers.IO) {
        runCatching { youtube.suggestionExtractor.suggestionList(query) }.getOrDefault(emptyList())
    }

    /**
     * كل بيانات المقطع: العنوان، القناة، الوصف، المقترحات،
     * وروابط البث (فيديو / صوت / بث مباشر HLS و DASH).
     */
    suspend fun streamInfo(url: String, forceRefresh: Boolean = false): StreamInfo =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            if (!forceRefresh) {
                cache.get(url)?.let { (time, info) ->
                    if (now - time < CACHE_TTL_MS) return@withContext info
                }
            }
            StreamInfo.getInfo(youtube, url).also { cache.put(url, now to it) }
        }

    /** يوحّد روابط يوتيوب (youtu.be، shorts، m.youtube...) أو يعيد null إن لم تكن رابط فيديو */
    fun normalizeVideoUrl(url: String): String? = runCatching {
        val factory = youtube.streamLHFactory
        if (factory.acceptUrl(url)) factory.fromUrl(url).url else null
    }.getOrNull()
}
