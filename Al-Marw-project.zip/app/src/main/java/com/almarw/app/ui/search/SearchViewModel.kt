package com.almarw.app.ui.search

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.almarw.app.data.NewPipeRepository
import com.almarw.app.data.SearchFilter
import com.almarw.app.data.SearchPage
import com.almarw.app.data.UiItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface SearchState {
    data object Idle : SearchState
    data object Loading : SearchState
    data class Results(val items: List<UiItem>, val hasMore: Boolean, val suggestion: String?) : SearchState
    data class Failed(val error: Throwable) : SearchState
}

/** حالة البحث تعيش هنا، فتبقى النتائج كما هي عند الرجوع من صفحة المقطع */
class SearchViewModel : ViewModel() {

    var query by mutableStateOf("")
        private set
    var filter by mutableStateOf(SearchFilter.ALL)
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set
    var state by mutableStateOf<SearchState>(SearchState.Idle)
        private set

    private var page: SearchPage? = null
    private var suggestJob: Job? = null
    private var searchJob: Job? = null
    private var loadingMore = false

    fun onQueryChange(text: String) {
        query = text
        suggestJob?.cancel()
        if (text.isBlank()) {
            suggestions = emptyList()
            return
        }
        suggestJob = viewModelScope.launch {
            delay(300) // ننتظر توقف الكتابة قبل طلب الاقتراحات
            suggestions = NewPipeRepository.suggestions(text)
        }
    }

    fun search(text: String = query) {
        if (text.isBlank()) return
        query = text
        suggestJob?.cancel()
        suggestions = emptyList()
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            state = SearchState.Loading
            state = try {
                val result = NewPipeRepository.search(text.trim(), filter)
                page = result
                result.toState()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                SearchState.Failed(e)
            }
        }
    }

    fun selectFilter(newFilter: SearchFilter) {
        if (newFilter == filter) return
        filter = newFilter
        if (query.isNotBlank()) search()
    }

    fun loadMore() {
        val current = page ?: return
        if (current.nextPage == null || loadingMore) return
        loadingMore = true
        viewModelScope.launch {
            try {
                val next = NewPipeRepository.searchMore(current)
                if (page === current) { // لم يبدأ بحث جديد أثناء التحميل
                    page = next
                    state = next.toState()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // فشل الصفحة التالية لا يمسح النتائج الحالية
            } finally {
                loadingMore = false
            }
        }
    }

    private fun SearchPage.toState() =
        SearchState.Results(items, hasMore = nextPage != null, suggestion = suggestion)
}
