package com.almarw.app.ui.search

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.almarw.app.R
import com.almarw.app.data.SearchFilter
import com.almarw.app.data.UiItem
import com.almarw.app.ui.common.EmptyHint
import com.almarw.app.ui.common.ErrorBox
import com.almarw.app.ui.common.ResultRow

/** الشاشة الرئيسية: شريط بحث أعلى الشاشة + فلاتر + النتائج */
@Composable
fun SearchScreen(
    onOpenVideo: (String) -> Unit,
    bottomBar: @Composable () -> Unit,
    viewModel: SearchViewModel = viewModel(),
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val submit: (String) -> Unit = { text ->
        viewModel.search(text)
        focusManager.clearFocus()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
        ) {
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(8.dp))
            SearchField(
                value = viewModel.query,
                onValueChange = viewModel::onQueryChange,
                onSearch = { submit(viewModel.query) },
                onClear = { viewModel.onQueryChange("") },
            )
            Spacer(Modifier.height(10.dp))
            FilterRow(selected = viewModel.filter, onSelect = viewModel::selectFilter)
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (viewModel.suggestions.isNotEmpty()) {
                SuggestionList(viewModel.suggestions, onPick = submit)
            } else {
                when (val s = viewModel.state) {
                    SearchState.Idle -> EmptyHint(stringResource(R.string.empty_home))
                    SearchState.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    is SearchState.Failed -> ErrorBox(
                        s.error,
                        onRetry = { viewModel.search() },
                        modifier = Modifier.align(Alignment.Center),
                    )
                    is SearchState.Results -> ResultsList(
                        results = s,
                        onOpenVideo = onOpenVideo,
                        onOpenOther = {
                            Toast.makeText(context, R.string.channel_next_phase, Toast.LENGTH_SHORT).show()
                        },
                        onLoadMore = viewModel::loadMore,
                        onSuggestion = submit,
                    )
                }
            }
        }
        bottomBar()
    }
}

@Composable
private fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit,
    onClear: () -> Unit,
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(stringResource(R.string.search_hint)) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = if (value.isNotEmpty()) {
            {
                IconButton(onClick = onClear) {
                    Icon(Icons.Filled.Clear, contentDescription = stringResource(R.string.search_clear))
                }
            }
        } else {
            null
        },
        singleLine = true,
        shape = RoundedCornerShape(24.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = MaterialTheme.colorScheme.primary,
        ),
    )
}

@Composable
private fun FilterRow(selected: SearchFilter, onSelect: (SearchFilter) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SearchFilter.entries.forEach { filter ->
            val isSelected = filter == selected
            Text(
                text = stringResource(filter.labelRes()),
                style = MaterialTheme.typography.labelLarge,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onSelect(filter) }
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            )
        }
    }
}

private fun SearchFilter.labelRes(): Int = when (this) {
    SearchFilter.ALL -> R.string.filter_all
    SearchFilter.VIDEOS -> R.string.filter_videos
    SearchFilter.CHANNELS -> R.string.filter_channels
}

@Composable
private fun SuggestionList(suggestions: List<String>, onPick: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(suggestions) { suggestion ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onPick(suggestion) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    suggestion,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun ResultsList(
    results: SearchState.Results,
    onOpenVideo: (String) -> Unit,
    onOpenOther: () -> Unit,
    onLoadMore: () -> Unit,
    onSuggestion: (String) -> Unit,
) {
    if (results.items.isEmpty()) {
        EmptyHint(stringResource(R.string.no_results))
        return
    }
    val listState = rememberLazyListState()
    // نجلب الصفحة التالية تلقائياً عند الاقتراب من نهاية القائمة
    val nearEnd by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= listState.layoutInfo.totalItemsCount - 5
        }
    }
    LaunchedEffect(nearEnd, results.items.size) {
        if (nearEnd && results.hasMore) onLoadMore()
    }

    LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
        results.suggestion?.let { corrected ->
            item {
                Text(
                    stringResource(R.string.did_you_mean, corrected),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSuggestion(corrected) }
                        .padding(16.dp),
                )
            }
        }
        items(results.items) { item ->
            ResultRow(item, onClick = {
                if (item is UiItem.Video) onOpenVideo(item.url) else onOpenOther()
            })
        }
        if (results.hasMore) {
            item {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                }
            }
        }
    }
}
