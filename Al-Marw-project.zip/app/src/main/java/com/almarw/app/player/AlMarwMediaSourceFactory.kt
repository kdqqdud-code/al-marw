package com.almarw.app.player

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.dash.manifest.DashManifestParser
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import org.schabi.newpipe.extractor.services.youtube.dashmanifestcreators.YoutubeProgressiveDashManifestCreator
import org.schabi.newpipe.extractor.stream.Stream

/**
 * يحوّل ResolvedSource إلى MediaSource يفهمه ExoPlayer.
 * الحيلة المهمة (نفس NewPipe): نحوّل ملف يوتيوب إلى DASH manifest محلي،
 * فيُحمَّل على قطع صغيرة بدل طلب واحد ضخم يبطّئه يوتيوب، ويصبح التقديم والترجيع أسرع.
 */
@OptIn(UnstableApi::class)
class AlMarwMediaSourceFactory(context: Context) : MediaSource.Factory {

    private val dataSourceFactory: DataSource.Factory = YoutubeDataSource.factory(context)
    private val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
    private val dashFactory = DashMediaSource.Factory(dataSourceFactory)
    private val hlsFactory = HlsMediaSource.Factory(dataSourceFactory)
    private val defaultFactory = DefaultMediaSourceFactory(dataSourceFactory)

    override fun createMediaSource(mediaItem: MediaItem): MediaSource {
        val source = mediaItem.localConfiguration?.tag as? ResolvedSource
            ?: return defaultFactory.createMediaSource(mediaItem) // ملف محلي أو رابط عادي

        return when (source) {
            is ResolvedSource.Hls -> hlsFactory.createMediaSource(mediaItem.withUri(source.uri))
            is ResolvedSource.Dash -> dashFactory.createMediaSource(mediaItem.withUri(source.uri))
            is ResolvedSource.Single -> youtubeSource(source.stream, source.durationSec, mediaItem)
            is ResolvedSource.Merged -> MergingMediaSource(
                youtubeSource(source.video, source.durationSec, mediaItem),
                youtubeSource(source.audio, source.durationSec, mediaItem),
            )
        }
    }

    private fun youtubeSource(stream: Stream, durationSec: Long, item: MediaItem): MediaSource {
        val itag = stream.itagItem
        if (itag != null) {
            try {
                val manifest = YoutubeProgressiveDashManifestCreator
                    .fromProgressiveStreamingUrl(stream.content, itag, durationSec)
                val parsed = DashManifestParser()
                    .parse(Uri.parse(stream.content), manifest.byteInputStream())
                return dashFactory.createMediaSource(parsed, item.withUri(stream.content))
            } catch (e: Exception) {
                Log.w(TAG, "DASH manifest failed, falling back to progressive", e)
            }
        }
        return progressiveFactory.createMediaSource(item.withUri(stream.content))
    }

    private fun MediaItem.withUri(uri: String): MediaItem = buildUpon().setUri(uri).build()

    override fun setDrmSessionManagerProvider(provider: DrmSessionManagerProvider): MediaSource.Factory {
        progressiveFactory.setDrmSessionManagerProvider(provider)
        dashFactory.setDrmSessionManagerProvider(provider)
        hlsFactory.setDrmSessionManagerProvider(provider)
        defaultFactory.setDrmSessionManagerProvider(provider)
        return this
    }

    override fun setLoadErrorHandlingPolicy(policy: LoadErrorHandlingPolicy): MediaSource.Factory {
        progressiveFactory.setLoadErrorHandlingPolicy(policy)
        dashFactory.setLoadErrorHandlingPolicy(policy)
        hlsFactory.setLoadErrorHandlingPolicy(policy)
        defaultFactory.setLoadErrorHandlingPolicy(policy)
        return this
    }

    override fun getSupportedTypes(): IntArray =
        intArrayOf(C.CONTENT_TYPE_DASH, C.CONTENT_TYPE_HLS, C.CONTENT_TYPE_OTHER)

    private companion object {
        const val TAG = "AlMarwMediaSource"
    }
}
