package com.almarw.app

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.almarw.app.data.NewPipeRepository
import com.almarw.app.player.rememberMediaController
import com.almarw.app.player.rememberNowPlaying
import com.almarw.app.ui.player.MiniPlayer
import com.almarw.app.ui.player.PlayerScreen
import com.almarw.app.ui.search.SearchScreen
import com.almarw.app.ui.theme.AlMarwTheme

class MainActivity : ComponentActivity() {

    /** رابط وصل عبر «مشاركة» ولم يُفتح بعد */
    private var incomingUrl by mutableStateOf<String?>(null)
    private var pipEligible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) incomingUrl = readSharedUrl(intent)

        setContent {
            AlMarwTheme {
                val controller = rememberMediaController()
                val nowPlaying = rememberNowPlaying(controller)
                // مكدّس بسيط للشاشات: فارغ = شاشة البحث، وآخر عنصر = المقطع المفتوح
                val stack = remember { mutableStateListOf<String>() }

                LaunchedEffect(incomingUrl) {
                    incomingUrl?.let {
                        stack.add(it)
                        incomingUrl = null
                    }
                }

                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val current = stack.lastOrNull()
                    if (current == null) {
                        SearchScreen(
                            onOpenVideo = { stack.add(it) },
                            bottomBar = {
                                MiniPlayer(
                                    nowPlaying = nowPlaying,
                                    player = controller,
                                    onOpen = { nowPlaying.mediaId?.let { id -> stack.add(id) } },
                                )
                            },
                        )
                    } else {
                        BackHandler { stack.removeAt(stack.lastIndex) }
                        PlayerScreen(
                            url = current,
                            controller = controller,
                            onOpenVideo = { stack.add(it) },
                            onPipEligibleChange = { setPipEligible(it) },
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readSharedUrl(intent)?.let { incomingUrl = it }
    }

    /** «مشاركة» من تطبيق يوتيوب: نستخرج الرابط من النص ونتحقق أنه رابط فيديو */
    private fun readSharedUrl(intent: Intent?): String? {
        if (intent?.action != Intent.ACTION_SEND) return null
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return null
        val link = Regex("""https?://\S+""").find(text)?.value
        val normalized = link?.let { NewPipeRepository.normalizeVideoUrl(it) }
        if (normalized == null) {
            Toast.makeText(this, R.string.unsupported_link, Toast.LENGTH_LONG).show()
        }
        return normalized
    }

    // ── الصورة داخل صورة (PiP) ──

    private fun setPipEligible(eligible: Boolean) {
        pipEligible = eligible
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // أندرويد 12+: يدخل الوضع تلقائياً عند الخروج أثناء تشغيل فيديو
            setPictureInPictureParams(pipParams(autoEnter = eligible))
        }
    }

    private fun pipParams(autoEnter: Boolean): PictureInPictureParams =
        PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) setAutoEnterEnabled(autoEnter)
            }
            .build()

    /** أندرويد 8 إلى 11: ندخل الوضع يدوياً عند الضغط على زر الرئيسية */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipEligible && Build.VERSION.SDK_INT < Build.VERSION_CODES.S &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            runCatching { enterPictureInPictureMode(pipParams(autoEnter = false)) }
        }
    }
}
