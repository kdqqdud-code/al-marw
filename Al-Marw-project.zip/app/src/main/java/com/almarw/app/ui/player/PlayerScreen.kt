package com.almarw.app.ui.player

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.almarw.app.R
import com.almarw.app.data.NewPipeRepository
import com.almarw.app.data.UiItem
import com.almarw.app.data.VideoDetails
import com.almarw.app.data.toDetails
import com.almarw.app.player.PlayMode
import com.almarw.app.player.playYoutube
import com.almarw.app.player.rememberNowPlaying
import com.almarw.app.player.setVideoDisabled
import com.almarw.app.ui.common.ErrorBox
import com.almarw.app.ui.common.ResultRow
import com.almarw.app.ui.common.formatCount
import kotlinx.coroutines.CancellationException

private sealed interface DetailsState {
    data object Loading : DetailsState
    data class Ready(val details: VideoDetails) : DetailsState
    data class Failed(val error: Throwable) : DetailsState
}

/**
 * صفحة المقطع: الشاشة في الأعلى، وتحتها العنوان وأزرار «تشغيل / استماع فقط / حفظ».
 * الشاشة لا تملك المشغّل؛ تتحكم به عبر MediaController المتصل بـ PlaybackService،
 * لذلك يستمر التشغيل عند الخروج منها.
 */
@Composable
fun PlayerScreen(
    url: String,
    controller: MediaController?,
    onOpenVideo: (String) -> Unit,
    onPipEligibleChange: (Boolean) -> Unit,
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val inPip = rememberIsInPipMode()
    val nowPlaying = rememberNowPlaying(controller)
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    var reloadKey by remember { mutableIntStateOf(0) }
    var state by remember(url) { mutableStateOf<DetailsState>(DetailsState.Loading) }
    var mode by remember(url) { mutableStateOf(PlayMode.VIDEO) }
    var fullscreen by rememberSaveable { mutableStateOf(false) }

    // ١) جلب تفاصيل المقطع عبر NewPipeExtractor (تُحفظ في الكاش فتستفيد منها خدمة التشغيل)
    LaunchedEffect(url, reloadKey) {
        state = DetailsState.Loading
        state = try {
            DetailsState.Ready(NewPipeRepository.streamInfo(url).toDetails())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            DetailsState.Failed(e)
        }
    }
    val details = (state as? DetailsState.Ready)?.details

    // ٢) بدء التشغيل بعد جاهزية البيانات والاتصال بالخدمة
    LaunchedEffect(url, controller, details != null) {
        val player = controller ?: return@LaunchedEffect
        val current = player.currentMediaItem
        if (current != null && current.mediaId == url) {
            // المقطع شغّال مسبقاً (فُتح من المشغّل المصغّر): نعرض وضعه الحالي فقط
            mode = PlayMode.from(current.requestMetadata.extras)
        } else if (details != null) {
            player.playYoutube(url, mode, details.title)
        }
    }

    fun switchMode(newMode: PlayMode) {
        val player = controller ?: return
        val sameVideo = player.currentMediaItem?.mediaId == url
        if (newMode == mode && sameVideo) {
            player.play()
            return
        }
        mode = newMode
        val resumeAt = if (sameVideo) player.currentPosition else 0L
        player.playYoutube(url, newMode, details?.title, resumeAt)
    }

    // ٣) عند الخروج من التطبيق نوقف فك الفيديو ويستمر الصوت (إلا في وضع PiP)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, controller) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && activity?.isInPictureInPictureMode != true) {
                controller?.setVideoDisabled(true)
            } else if (event == Lifecycle.Event.ON_START) {
                controller?.setVideoDisabled(false)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // ٤) الصورة داخل صورة مسموحة فقط أثناء تشغيل فيديو هذا المقطع
    val pipEligible = nowPlaying.isPlaying && nowPlaying.mediaId == url && mode == PlayMode.VIDEO
    LaunchedEffect(pipEligible) { onPipEligibleChange(pipEligible) }

    // ٥) ملء الشاشة: بزر ملء الشاشة أو بتدوير الهاتف
    val immersive = (fullscreen || landscape) && !inPip
    LaunchedEffect(fullscreen) {
        activity?.requestedOrientation =
            if (fullscreen) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
    LaunchedEffect(immersive) {
        val window = activity?.window ?: return@LaunchedEffect
        val bars = WindowCompat.getInsetsController(window, window.decorView)
        if (immersive) {
            bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            bars.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            bars.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    BackHandler(enabled = fullscreen) { fullscreen = false }
    DisposableEffect(Unit) {
        onDispose {
            onPipEligibleChange(false)
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity?.window?.let {
                WindowCompat.getInsetsController(it, it.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // نفس الـ PlayerView في كل الأوضاع (عادي / ملء الشاشة / PiP) حتى لا ينقطع الفيديو
    val videoOnly = inPip || immersive
    Column(
        Modifier
            .fillMaxSize()
            .background(if (videoOnly) Color.Black else MaterialTheme.colorScheme.background)
            .then(if (videoOnly) Modifier else Modifier.statusBarsPadding()),
    ) {
        VideoSurface(
            player = controller,
            showControls = !inPip,
            keepScreenOn = nowPlaying.isPlaying && mode == PlayMode.VIDEO,
            artworkUrl = details?.thumbnail,
            onFullscreenClick = { fullscreen = !fullscreen },
            modifier = if (videoOnly) {
                Modifier.fillMaxSize()
            } else {
                Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            },
        )
        if (!videoOnly) {
            DetailsContent(
                state = state,
                mode = mode,
                onModeSelected = { switchMode(it) },
                onSave = {
                    // TODO المرحلة القادمة: قائمة الجودات + محرك التحميل
                    Toast.makeText(context, R.string.save_next_phase, Toast.LENGTH_SHORT).show()
                },
                onRetry = { reloadKey++ },
                onOpenVideo = onOpenVideo,
            )
        }
    }
}

/** شاشة الفيديو: PlayerView من Media3 داخل Compose */
@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun VideoSurface(
    player: Player?,
    showControls: Boolean,
    keepScreenOn: Boolean,
    artworkUrl: String?,
    onFullscreenClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val fullscreenClick by rememberUpdatedState(onFullscreenClick)

    // في وضع «استماع فقط» تظهر الصورة المصغّرة مكان الفيديو
    var artwork by remember { mutableStateOf<Drawable?>(null) }
    LaunchedEffect(artworkUrl) {
        artwork = artworkUrl?.let { url ->
            val request = ImageRequest.Builder(context).data(url).allowHardware(false).build()
            (context.imageLoader.execute(request) as? SuccessResult)?.drawable
        }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                setShowNextButton(false)
                setShowPreviousButton(false)
                setFullscreenButtonClickListener { fullscreenClick() }
                setErrorMessageProvider {
                    android.util.Pair.create(0, ctx.getString(R.string.error_playback))
                }
            }
        },
        update = { view ->
            view.player = player
            view.useController = showControls
            view.keepScreenOn = keepScreenOn
            view.defaultArtwork = artwork
        },
        onRelease = { view -> view.player = null },
        modifier = modifier.background(Color.Black),
    )
}

@Composable
private fun DetailsContent(
    state: DetailsState,
    mode: PlayMode,
    onModeSelected: (PlayMode) -> Unit,
    onSave: () -> Unit,
    onRetry: () -> Unit,
    onOpenVideo: (String) -> Unit,
) {
    when (state) {
        DetailsState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        is DetailsState.Failed -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            ErrorBox(state.error, onRetry)
        }
        is DetailsState.Ready -> {
            val d = state.details
            var expanded by rememberSaveable(d.url) { mutableStateOf(false) }
            LazyColumn(contentPadding = WindowInsets.navigationBars.asPaddingValues()) {
                item { TitleBlock(d) }
                item { ActionsRow(mode, onModeSelected, onSave) }
                if (d.description.isNotBlank()) {
                    item { DescriptionBlock(d.description, expanded) { expanded = !expanded } }
                }
                if (d.related.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.related),
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp),
                        )
                    }
                    items(d.related) { item ->
                        ResultRow(item, onClick = { if (item is UiItem.Video) onOpenVideo(item.url) })
                    }
                }
            }
        }
    }
}

@Composable
private fun TitleBlock(d: VideoDetails) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(d.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        val meta = listOfNotNull(
            if (d.isLive) stringResource(R.string.live) else null,
            formatCount(d.views)?.let { stringResource(R.string.views, it) },
            d.uploadedAgo,
        ).joinToString("، ")
        if (meta.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                meta,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = d.uploaderAvatar,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                d.uploader,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** أزرار NewPipe الثلاثة: الوضع الحالي يظهر بالأحمر */
@Composable
private fun ActionsRow(mode: PlayMode, onModeSelected: (PlayMode) -> Unit, onSave: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        ActionButton(
            icon = rememberVectorPainter(Icons.Filled.PlayArrow),
            label = stringResource(R.string.action_play),
            selected = mode == PlayMode.VIDEO,
            onClick = { onModeSelected(PlayMode.VIDEO) },
            modifier = Modifier.weight(1f),
        )
        ActionButton(
            icon = painterResource(R.drawable.ic_headset),
            label = stringResource(R.string.action_listen),
            selected = mode == PlayMode.AUDIO,
            onClick = { onModeSelected(PlayMode.AUDIO) },
            modifier = Modifier.weight(1f),
        )
        ActionButton(
            icon = painterResource(R.drawable.ic_download),
            label = stringResource(R.string.action_save),
            selected = false,
            onClick = onSave,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun ActionButton(
    icon: Painter,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val background = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val content = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = content, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun DescriptionBlock(text: String, expanded: Boolean, onToggle: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onToggle)
            .padding(12.dp),
    ) {
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            maxLines = if (expanded) Int.MAX_VALUE else 3,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            stringResource(if (expanded) R.string.show_less else R.string.show_more),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}
