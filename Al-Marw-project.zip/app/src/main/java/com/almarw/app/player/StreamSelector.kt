package com.almarw.app.player

import android.os.Bundle
import com.almarw.app.data.isLive
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.Stream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream

/** وضع التشغيل: فيديو كامل، أو صوت فقط (يوفّر البيانات والبطارية) */
enum class PlayMode {
    VIDEO, AUDIO;

    companion object {
        const val EXTRA_KEY = "almarw.play_mode"

        fun from(extras: Bundle?): PlayMode {
            val name = extras?.getString(EXTRA_KEY)
            return PlayMode.entries.firstOrNull { it.name == name } ?: PlayMode.VIDEO
        }
    }
}

/** ما اخترناه للتشغيل — يُحمَل داخل MediaItem ويقرؤه AlMarwMediaSourceFactory */
sealed interface ResolvedSource {
    val uri: String

    /** فيديو بلا صوت + صوت منفصل (هكذا يقدّم يوتيوب الجودات العالية) */
    data class Merged(
        val video: VideoStream,
        val audio: AudioStream,
        val durationSec: Long,
    ) : ResolvedSource {
        override val uri: String get() = video.content
    }

    /** ملف واحد: صوت فقط، أو فيديو مدمج معه الصوت */
    data class Single(val stream: Stream, val durationSec: Long) : ResolvedSource {
        override val uri: String get() = stream.content
    }

    /** بث مباشر أو ملف manifest جاهز من يوتيوب */
    data class Hls(override val uri: String) : ResolvedSource
    data class Dash(override val uri: String) : ResolvedSource
}

object StreamSelector {

    /** أقصى دقة افتراضية: 720p توازن بين الوضوح واستهلاك البيانات */
    var maxVideoHeight = 720

    fun select(info: StreamInfo, mode: PlayMode): ResolvedSource {
        val duration = info.duration

        // ١) البث المباشر: يوتيوب يقدّمه بصيغة HLS
        if (info.streamType.isLive()) {
            info.hlsUrl?.takeIf { it.isNotBlank() }?.let { return ResolvedSource.Hls(it) }
            info.dashMpdUrl?.takeIf { it.isNotBlank() }?.let { return ResolvedSource.Dash(it) }
        }

        val audio = bestAudio(info.audioStreams)

        // ٢) استماع فقط
        if (mode == PlayMode.AUDIO && audio != null) {
            return ResolvedSource.Single(audio, duration)
        }

        // ٣) فيديو بجودة عالية + صوت منفصل
        val videoOnly = bestVideo(info.videoOnlyStreams)
        if (videoOnly != null && audio != null) {
            return ResolvedSource.Merged(videoOnly, audio, duration)
        }

        // ٤) بدائل احتياطية: ملف مدمج، ثم HLS، ثم الصوت وحده
        bestVideo(info.videoStreams)?.let { return ResolvedSource.Single(it, duration) }
        info.hlsUrl?.takeIf { it.isNotBlank() }?.let { return ResolvedSource.Hls(it) }
        audio?.let { return ResolvedSource.Single(it, duration) }

        error("No playable stream found")
    }

    private fun <T : Stream> List<T>.playable(): List<T> =
        filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }

    private fun bestAudio(streams: List<AudioStream>): AudioStream? {
        val playable = streams.playable()
        // في المقاطع المدبلجة نفضّل الصوت الأصلي
        val original = playable
            .filter { it.audioTrackType == null || it.audioTrackType == AudioTrackType.ORIGINAL }
            .ifEmpty { playable }
        return original.maxWithOrNull(
            compareBy<AudioStream>(
                { if (it.format == MediaFormat.M4A) 1 else 0 }, // AAC: الأوسع توافقاً
                { it.averageBitrate },
            )
        )
    }

    private fun bestVideo(streams: List<VideoStream>): VideoStream? {
        val playable = streams.playable()
        val pool = playable.filter { it.height in 1..maxVideoHeight }.ifEmpty { playable }
        return pool.maxWithOrNull(
            compareBy<VideoStream>(
                { it.height },
                { codecScore(it.codec) }, // H.264 أولاً: فك ترميز بالعتاد على كل الأجهزة
                { it.fps },
            )
        )
    }

    private fun codecScore(codec: String?): Int = when {
        codec == null -> 0
        codec.startsWith("avc") -> 3
        codec.startsWith("vp9") || codec.startsWith("vp09") -> 2
        else -> 1 // av01 وغيرها
    }
}
