package com.almarw.app.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.almarw.app.R
import com.almarw.app.player.NowPlaying

/** شريط صغير أسفل شاشة البحث للمقطع الشغّال في الخلفية */
@Composable
fun MiniPlayer(nowPlaying: NowPlaying, player: Player?, onOpen: () -> Unit) {
    if (player == null || nowPlaying.mediaId == null) return
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onOpen)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                nowPlaying.title.orEmpty(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            nowPlaying.artist?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) {
            Icon(
                painter = if (nowPlaying.isPlaying) {
                    painterResource(R.drawable.ic_pause)
                } else {
                    rememberVectorPainter(Icons.Filled.PlayArrow)
                },
                contentDescription = stringResource(R.string.play_pause),
            )
        }
        IconButton(onClick = {
            player.stop()
            player.clearMediaItems()
        }) {
            Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.stop_playback))
        }
    }
}
