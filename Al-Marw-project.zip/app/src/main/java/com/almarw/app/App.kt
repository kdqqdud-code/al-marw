package com.almarw.app

import android.app.Application
import com.almarw.app.data.DownloaderImpl
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        // تهيئة NewPipeExtractor مرة واحدة عند تشغيل التطبيق:
        // المُنزِّل (الشبكة) + لغة المحتوى + الدولة (تؤثر على النتائج وصيغة التواريخ)
        NewPipe.init(
            DownloaderImpl.instance,
            Localization("ar", "OM"),
            ContentCountry("OM"),
        )
    }
}
