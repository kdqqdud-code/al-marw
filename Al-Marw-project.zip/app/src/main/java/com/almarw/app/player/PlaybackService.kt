package com.almarw.app.player

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.almarw.app.MainActivity
import com.almarw.app.R
import com.almarw.app.data.NewPipeRepository
import com.almarw.app.data.bestUrl
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.guava.future
import kotlinx.coroutines.launch

/**
 * خدمة التشغيل: المشغّل يعيش هنا وليس داخل الشاشة، لذلك يستمر الصوت
 * عند الخروج من التطبيق أو إطفاء الشاشة. MediaSessionService تتكفّل تلقائياً
 * بإشعار التحكم (تشغيل/إيقاف/تقديم) وبتحويل الخدمة إلى Foreground أثناء التشغيل.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var mediaSession: MediaSession? = null
    private var retriedMediaId: String? = null

    override fun onCreate() {
        super.onCreate()

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this)
                .setChannelName(R.string.notification_channel)
                .build()
                .apply { setSmallIcon(R.drawable.ic_headset) }
        )

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(AlMarwMediaSourceFactory(this))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // إيقاف مؤقت عند فصل السماعة
            .setWakeMode(C.WAKE_MODE_NETWORK)  // يمنع انقطاع البث والشاشة مطفأة
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                retryWithFreshLinks(player)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) retriedMediaId = null
            }
        })

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        mediaSession = MediaSession.Builder(this, player)
            .setCallback(ResolveCallback())
            .setSessionActivity(openApp) // الضغط على الإشعار يفتح التطبيق
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    /** عند سحب التطبيق من قائمة التطبيقات الأخيرة: نتوقف فقط إن لم يكن هناك تشغيل */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 ||
            player.playbackState == Player.STATE_ENDED
        ) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    /**
     * الواجهة ترسل "رابط يوتيوب" فقط، وهنا نحوّله إلى روابط بث حقيقية عبر NewPipeExtractor.
     * Media3 تنتظر هذا الـ Future قبل التشغيل، فلا تتجمّد الواجهة.
     */
    private inner class ResolveCallback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> = scope.future {
            mediaItems.map { resolve(it) }.toMutableList()
        }
    }

    private suspend fun resolve(item: MediaItem, forceRefresh: Boolean = false): MediaItem {
        val url = item.requestMetadata.mediaUri?.toString() ?: item.mediaId
        val mode = PlayMode.from(item.requestMetadata.extras)
        val info = NewPipeRepository.streamInfo(url, forceRefresh)
        val source = StreamSelector.select(info, mode)

        return MediaItem.Builder()
            .setMediaId(item.mediaId)
            .setUri(source.uri)
            .setTag(source)
            .setRequestMetadata(item.requestMetadata) // نحتفظ بها لإعادة الجلب عند انتهاء الروابط
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(info.name)
                    .setArtist(info.uploaderName)
                    .setArtworkUri(info.thumbnails.bestUrl()?.let(Uri::parse))
                    .build()
            )
            .build()
    }

    /** روابط يوتيوب تنتهي بعد ساعات: عند أول خطأ نعيد جلبها ونكمل من نفس الثانية */
    private fun retryWithFreshLinks(player: ExoPlayer) {
        val item = player.currentMediaItem ?: return
        if (retriedMediaId == item.mediaId) return
        retriedMediaId = item.mediaId
        val position = player.currentPosition
        scope.launch {
            runCatching { resolve(item, forceRefresh = true) }.onSuccess { fresh ->
                player.setMediaItem(fresh, position)
                player.prepare()
                player.play()
            }
        }
    }
}
