package com.almarw.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/** ألوان التطبيق — غيّرها من هنا (قريبة من الوضع الليلي في NewPipe) */
object AlMarwColors {
    val Background = Color(0xFF1F1F1F)  // خلفية الشاشات
    val Surface = Color(0xFF2A2A2A)     // الشريط العلوي والبطاقات
    val SurfaceHigh = Color(0xFF363636) // حقل البحث والأزرار غير المفعّلة
    val Accent = Color(0xFFE53935)      // الأحمر: الزر المفعّل وشريط التقدّم و«مباشر»
    val TextPrimary = Color(0xFFF2F2F2)
    val TextSecondary = Color(0xFFA6A6A6)
}

private val DarkScheme = darkColorScheme(
    primary = AlMarwColors.Accent,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF5C1614),
    onPrimaryContainer = Color(0xFFFFDAD6),
    secondary = AlMarwColors.Accent,
    onSecondary = Color.White,
    secondaryContainer = AlMarwColors.SurfaceHigh,
    onSecondaryContainer = AlMarwColors.TextPrimary,
    background = AlMarwColors.Background,
    onBackground = AlMarwColors.TextPrimary,
    surface = AlMarwColors.Surface,
    onSurface = AlMarwColors.TextPrimary,
    surfaceVariant = AlMarwColors.SurfaceHigh,
    onSurfaceVariant = AlMarwColors.TextSecondary,
    surfaceTint = AlMarwColors.Surface,
    surfaceContainerLowest = AlMarwColors.Background,
    surfaceContainerLow = Color(0xFF252525),
    surfaceContainer = AlMarwColors.Surface,
    surfaceContainerHigh = Color(0xFF303030),
    surfaceContainerHighest = AlMarwColors.SurfaceHigh,
    outline = Color(0xFF4A4A4A),
)

/** الواجهة عربية بالكامل، فنثبّت الاتجاه من اليمين لليسار حتى لو كانت لغة الهاتف إنجليزية */
private const val FORCE_RTL = true

@Composable
fun AlMarwTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme) {
        if (FORCE_RTL) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, content = content)
        } else {
            content()
        }
    }
}
