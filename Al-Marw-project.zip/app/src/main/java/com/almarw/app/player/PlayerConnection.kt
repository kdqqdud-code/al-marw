package com.almarw.app.player

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

/** يتصل بخدمة التشغيل ويعيد MediaController (أو null حتى يكتمل الاتصال) */
@Composable
fun rememberMediaController(): MediaController? {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            { controller = runCatching { future.get() }.getOrNull() },
            ContextCompat.getMainExecutor(context),
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller = null
        }
    }
    return controller
}

/** تشغيل مقطع: نرسل رابط يوتيوب ووضع التشغيل فقط، والخدمة تستخرج روابط البث */
fun Player.playYoutube(url: String, mode: PlayMode, title: String?, startAtMs: Long = 0L) {
    val item = MediaItem.Builder()
        .setMediaId(url)
        .setRequestMetadata(
            MediaItem.RequestMetadata.Builder()
                .setMediaUri(Uri.parse(url))
                .setExtras(Bundle().apply { putString(PlayMode.EXTRA_KEY, mode.name) })
                .build()
        )
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
        .build()
    setMediaItem(item, startAtMs)
    prepare()
    play()
}

/** في الخلفية نوقف فك ترميز الفيديو ويبقى الصوت، لتوفير البيانات والبطارية */
fun Player.setVideoDisabled(disabled: Boolean) {
    trackSelectionParameters = trackSelectionParameters.buildUpon()
        .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, disabled)
        .build()
}

@Immutable
data class NowPlaying(
    val mediaId: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val isPlaying: Boolean = false,
)

/** حالة المشغّل الحالية كـ State لـ Compose (للمشغّل المصغّر وقرار PiP) */
@Composable
fun rememberNowPlaying(player: Player?): NowPlaying {
    var state by remember(player) { mutableStateOf(player.snapshot()) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                state = player.snapshot()
            }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }
    return state
}

private fun Player?.snapshot() = NowPlaying(
    mediaId = this?.currentMediaItem?.mediaId,
    title = this?.mediaMetadata?.title?.toString(),
    artist = this?.mediaMetadata?.artist?.toString(),
    isPlaying = this?.isPlaying == true,
)
