package com.almarw.app.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.almarw.app.R
import com.almarw.app.data.UiItem

/** صف واحد في القوائم (نتائج البحث والمقترحات) حسب نوع العنصر */
@Composable
fun ResultRow(item: UiItem, onClick: () -> Unit) {
    when (item) {
        is UiItem.Video -> MediaRow(
            thumbnail = item.thumbnail,
            badge = if (item.isLive) stringResource(R.string.live) else formatDuration(item.durationSec),
            badgeIsLive = item.isLive,
            title = item.title,
            line1 = item.uploader,
            line2 = listOfNotNull(
                formatCount(item.views)?.let { stringResource(R.string.views, it) },
                item.uploadedAgo,
            ).joinToString("، "),
            onClick = onClick,
        )
        is UiItem.Playlist -> MediaRow(
            thumbnail = item.thumbnail,
            badge = formatCount(item.count)?.let { stringResource(R.string.videos_count, it) },
            badgeIsLive = false,
            title = item.title,
            line1 = item.uploader,
            line2 = "",
            onClick = onClick,
        )
        is UiItem.Channel -> ChannelRow(item, onClick)
    }
}

@Composable
private fun MediaRow(
    thumbnail: String?,
    badge: String?,
    badgeIsLive: Boolean,
    title: String,
    line1: String,
    line2: String,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Box(
            Modifier
                .width(168.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black),
        ) {
            AsyncImage(
                model = thumbnail,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (badge != null) {
                Text(
                    badge,
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .background(
                            if (badgeIsLive) MaterialTheme.colorScheme.primary else Color(0xCC000000),
                            RoundedCornerShape(4.dp),
                        )
                        .padding(horizontal = 4.dp, vertical = 1.dp),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(4.dp))
            if (line1.isNotEmpty()) SecondaryText(line1)
            if (line2.isNotEmpty()) SecondaryText(line2)
        }
    }
}

@Composable
private fun ChannelRow(channel: UiItem.Channel, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(168.dp), contentAlignment = Alignment.Center) {
            AsyncImage(
                model = channel.thumbnail,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                channel.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            formatCount(channel.subscribers)?.let {
                SecondaryText(stringResource(R.string.subscribers, it))
            }
        }
    }
}

@Composable
private fun SecondaryText(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}
