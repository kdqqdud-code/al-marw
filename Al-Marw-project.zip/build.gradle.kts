// ملف الجذر: يعرّف الإضافات وإصداراتها فقط، ووحدة app تستخدمها
plugins {
    id("com.android.application") version "8.13.0" apply false
    id("org.jetbrains.kotlin.android") version "2.2.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.0" apply false
}
